CREATE TABLE "items" (
  "value" TEXT NOT NULL,
  CONSTRAINT "items_pkey" PRIMARY KEY ("value")
) WITHOUT ROWID;
